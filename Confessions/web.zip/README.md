
MSIT Confessions
Aim: Every user can confess his/her personal opinions either openly or anonymously.

Description: MSIT Confessions blog allows users to share their views on all aspects either anonymously or with identity. This provides a platform to express the ideas for the people with fear. It acts as a medium to share emotions, troubles, thoughts. It also helps to provide feedback to someone anonymously, which helps to know the strength/weakness about them.
Features:
Access through credentials.
Post an article.
About us( Basic information with profile pic).
Social login through Gmail.
Rate an article.
Sharing a post through gmail.

Team members and responsibilities:
Pradeep Burugu (Backend developer)
Vignan Thota (Backend developer)
Sai Kumar Guttula (UI Developer)
Bindu Yadamakanti(UI Developer)
Gaurav Singh(Resource Provider)
